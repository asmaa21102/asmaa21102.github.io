<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\BrowserDemoServiceProvider::class,
];
