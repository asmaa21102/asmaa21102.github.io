<?php

namespace App\Providers;

use Illuminate\Database\Connection;
use Illuminate\Database\Events\ConnectionEstablished;
use Illuminate\Support\Facades\Event;
use Illuminate\Support\ServiceProvider;

/**
 * Added only in the browser demo build (SQLite): MySQL's DATE_FORMAT(date, format) for the
 * few format letters the app uses, so the same queries run unchanged.
 */
class BrowserDemoServiceProvider extends ServiceProvider
{
    public function boot(): void
    {
        // Connections opened later get it when they open; one already open gets it now.
        Event::listen(ConnectionEstablished::class, fn (ConnectionEstablished $e) => self::addFunctions($e->connection));
        foreach ($this->app['db']->getConnections() as $connection) {
            self::addFunctions($connection);
        }
    }

    private static function addFunctions(Connection $connection): void
    {
        if ($connection->getDriverName() !== 'sqlite') {
            return;
        }
        $dateFormat = static function (?string $value, string $format): ?string {
            if ($value === null || $value === '') {
                return null;
            }

            return date(strtr($format, ['%Y' => 'Y', '%m' => 'm', '%d' => 'd', '%H' => 'H', '%i' => 'i', '%s' => 's']), strtotime($value));
        };
        $pdo = $connection->getPdo();
        method_exists($pdo, 'createFunction')
            ? $pdo->createFunction('DATE_FORMAT', $dateFormat, 2)
            : $pdo->sqliteCreateFunction('DATE_FORMAT', $dateFormat, 2);
    }
}
