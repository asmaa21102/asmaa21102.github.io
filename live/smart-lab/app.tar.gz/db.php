<?php
// Browser demo: SQLite instead of MySQL (same tables), and MySQL's NOW() for save_analysis.php.
try {
    $pdo = PDO::connect("sqlite:/app/data/database.sqlite");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->createFunction("NOW", fn () => gmdate("Y-m-d H:i:s"), 0);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
